function saveSettings() {
	const spOtherUrls = document.querySelector('#spte-other-urls');
	chrome.storage.sync.get('spteSettings', (data) => {
		if (chrome.runtime.error || !spOtherUrls) {	return;	}
		let settings = {};
		if (data.spteSettings) {
			settings = data.spteSettings;
		} else {
			settings = {
				spteOtherUrls: '',
			};
		}
		settings.spteOtherUrls = spOtherUrls.value;
		chrome.storage.sync.set({ spteSettings: settings }, () => {
			if (chrome.runtime.error) {	console.log('Impossible d’enregistrer les paramètres');	}
		});
	});
}

function restoreSettings() {
	chrome.storage.sync.get('spteSettings', (data) => {
		if (chrome.runtime.error) {	return;	}
		const spOtherUrls = document.querySelector('#spte-other-urls');
		if (data.spteSettings && spOtherUrls && data.spteSettings.spteOtherUrls) {
			spOtherUrls.value = data.spteSettings.spteOtherUrls;
		}
	});
}

document.addEventListener('DOMContentLoaded', restoreSettings);
document.querySelector('#spte-settings-submit').addEventListener('click', (e) => {
	e.preventDefault();
	saveSettings();
});
